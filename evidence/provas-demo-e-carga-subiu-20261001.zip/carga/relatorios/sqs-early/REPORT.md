# Evidências de stress com Grafana

Janela UTC: 2026-10-01T08:45:31.201Z → 2026-10-01T08:55:48.199Z

| Fase | Requisições | Erros | req/s | p95 cliente (ms) | CPU média / pico (%) | RSS pico (MiB) | Event loop p99 pico (ms) | Outbox pico | Lag pico (s) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| http-12 | 2500 | 0 | 135.24 | 149.69 | 61.07 / 95.92 | 264.37 | 31.24 | 4418 | 15.61 |
| http-48 | 2500 | 0 | 118.99 | 853.68 | 52.80 / 85.58 | 281.06 | 33.91 | 4451 | 17.84 |
| http-96 | 2500 | 0 | 99.16 | 1318.81 | 58.33 / 97.92 | 311.54 | 71.30 | 4004 | 20.33 |
| hot-wallet | 685 | 0 | 20.73 | 3641.95 | 18.95 / 25.20 | 218.65 | 11.74 | 1100 | 26.51 |
| replays | 10000 | 0 | 388.31 | 388.41 | 65.97 / 107.32 | 299.88 | 103.48 | 0 | 0.00 |

## Consumo, recuperação e SQS

CPU do processo: pico amostrado 111.27% de um núcleo (rate de 30 s). RSS: baseline médio 142.35 MiB; pico 311.54 MiB; último valor 198.07 MiB. A memória caiu após a carga, mas não voltou ao baseline; esta janela curta não comprova nem descarta vazamento.

Event loop: maior p99 entre scrapes 124.52 ms. A carteira única teve até 11 sessões SQL esperando locks; o contador de conflitos/timeout permaneceu zero. Espera por serialização não é erro de lock.

Outbox: pico amostrado 4986 eventos e lag máximo 108.76 s. Recovery após http-12/http-48/http-96: 77.65 s, 85.81 s, 109.30 s. Todas as fases terminaram com outbox drenada.

SQS: 1100 entregas / 1000 comandos únicos, 76.46 s até drenagem e 13.08 comandos únicos/s. Fila visível no Prometheus chegou a 1051 e retornou a zero. Counter de duplicatas final: 10100 (10.000 HTTP + 100 SQS). Inbox final: 1.000 registros. DLQ vazia e nenhuma falha persistida.

| Container | CPU máxima amostrada (%) | Memória máxima Docker (MiB) |
| --- | ---: | ---: |
| app-observed | 153.01 | 268.60 |
| postgres | 409.16 | 142.60 |
| localstack | 122.23 | 188.30 |
| prometheus | 4.21 | 45.77 |
| tempo | 5.42 | 104.30 |
| grafana | 20.63 | 883.70 |

## Auditoria final

```json
{
  "wallets": "265",
  "divergent_wallets": "0",
  "ledger": "9458",
  "journals": "9458",
  "journal_lines": "18916",
  "unbalanced_journals": "0",
  "inbox": "1000",
  "outbox_pending": "0",
  "failed_deliveries": "0"
}
```

Readiness: 0 falhas / 234 amostras.
Achados registrados: []

## Metodologia e leitura dos resultados

Uma aplicação Bun 1.4.2, PostgreSQL e SQS LocalStack reais, tracing ativo. Gerador em container separado, no mesmo host Docker; o cluster principal permaneceu ativo e ocioso. Carga fechada: cada cliente aguarda a resposta anterior. Cada fase HTTP dura até 30 s ou o limite de requisições, o que ocorrer primeiro. Carteiras novas por fase; BETs de 0.01 BRL; a ordem acumula históricos diferentes e não representa comparação independente de benchmark.

A latência cliente mede a resposta HTTP inteira; o p95 do Grafana vem da interpolação dos buckets do histograma de processamento. O rate de CPU usa janela de 30 s e expressa percentual de um núcleo, podendo exceder 100%. RSS vem do processo; docker stats desconta parte do cache e não mede a mesma coisa. Prometheus amostra a cada 5 s; monitor independente a cada 2.5 s mais o tempo da coleta. Picos breves podem escapar. Médias são das amostras disponíveis e incluem reconciliação breve ao fim da fase.

Docker stats reporta CPU em uma janela curta; seus picos não são comparáveis diretamente ao rate de 30 s do Prometheus. Não foram fixadas quotas de CPU/memória; a VM Docker reportou 16 CPUs lógicas e 19 GiB. O Grafana também foi aberto durante o experimento, com custo registrado na tabela de containers.

Replays foram semeados antes da medição, com 50 ms de pausa por cliente; não são diretamente comparáveis às gravações financeiras. A rajada SQS envia 1.100 entregas para 1.000 comandos únicos, com deduplicação de transporte distinta para comprovar inbox SQL. A taxa SQS inclui envio, processamento e drenagem da fila. Os tempos de recovery começam após a reconciliação; não são o tempo completo desde o último commit.

A fila de saída conserva eventos publicados porque não há consumidor downstream neste experimento. Ela pode crescer mesmo quando a outbox está drenada. Os testes de concorrência/crash são outra evidência, executada separadamente da medição. Esta carga local não determina capacidade máxima nem SLO de produção ou performance AWS.

## Arquivos

- `experiment.json`, `analysis.json`: resultados e agregações por fase.
- `prometheus-series.json`, `server-samples.jsonl`, `docker-stats.jsonl`: séries e amostras brutas.
- `*-latencies.json`, `*-reconciliation.json`, `sqs-reconciliation.json`: latências e conferências de saldos.
- `stress.ts`, `collect-docker.py`, `analyze.py`, `stack.env`, `override.yaml`: procedimento e análise reproduzíveis.
- `source-commit.txt`, `source-diff.patch`, `dashboard.json`: código efetivamente medido.
- `resources.png`, `messaging.png`, `http-comparison.png`, `grafana-*.jpg`: figuras e capturas reais quando disponíveis.

## Validação após a medição

verify:full: passed=True, 2026-10-01T08:58:51.384Z → 2026-10-01T08:59:53.882Z. JUnit: 103 testes, 811 assertions, 0 falhas, 0 skips. Typecheck, lint, formato e todas as suítes passaram. O gate usou recursos exclusivos e foi executado após a janela medida.

Capturas parciais reais: `grafana-resources-crop.jpg` registra a fase inicial; `grafana-final.jpg` registra a janela completa. Capturas grandes falharam por timeout da ferramenta. As figuras PNG foram geradas dos dados exportados, sem substituir ou simular screenshots do Grafana.
